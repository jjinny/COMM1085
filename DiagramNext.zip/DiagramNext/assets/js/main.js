// Tooltips and Popovers // 
// =================================================== // 
$('.tooltips-link').tooltip();
        $('.popovers-link').popover({
            html: true
        }); // enable html in popover

        $('body').on('click', function (e) {
            $('[data-toggle="popover"]').each(function () {
                //the 'is' for buttons that trigger popups
                //the 'has' for icons within a button that triggers a popup
                if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
                    $(this).popover('hide');
                }
            });
        });
// Script for Accordions // 
// =================================================== // 

		$('.panel-group').before('<div class="controlsAcc"><a href="javascript:expandAllAcc()">Expand All</a> / <a href="javascript:collapseAllAcc()">Collapse All</a></div>');

        $('.panel-collapse').on('show.bs.collapse', function () {
            var title_elem = $(this).parent('.panel-default').find('.panel-title');
            //$('.panel-title').removeClass('active');
            //$('.collapse.in').collapse('hide');
            title_elem.addClass('active');
            setIconOpened(title_elem);
        });

        $('.panel-collapse').on('hide.bs.collapse', function () {
            var title_elem = $(this).parent('.panel-default').find('.panel-title');
            title_elem.removeClass('active');
            setIconOpened(null);

        });

        // create a function to set the open icon for the given panel
        // clearing out all the rest (activePanel CAN be null if nothing is open)
        function setIconOpened(activePanel) {
            $('.panel-title').find('b').addClass('closed').removeClass('opened');

           if (activePanel) {
               $(activePanel).find('b').addClass('opened').removeClass('closed');
            }
        }


		jQuery(function ($) {
			var $active = $('#accordion .panel-collapse.in').prev().addClass('active');
			$active.find('a').append('<span class="glyphicon glyphicon-minus pull-right"></span>');
			$('#accordion .panel-heading').not($active).find('a').prepend('<span class="glyphicon glyphicon-plus pull-right"></span>');
			$('#accordion').on('show.bs.collapse', function (e)
			{
				$('#accordion .panel-heading.active').removeClass('active').find('.glyphicon').removeClass('glyphicon-plus').addClass('glyphicon-minus');
				$(e.target).prev().addClass('active').find('.glyphicon').removeClass('glyphicon-plus').addClass('glyphicon-minus');
			});
			$('#accordion').on('hide.bs.collapse', function (e)
			{
				$(e.target).prev().removeClass('active').find('.glyphicon').removeClass('glyphicon-minus').addClass('glyphicon-plus');
			});
		});		

		
		function expandAllAcc() {
			$('#accordion > .panel > .collapse').collapse('show');
		}


		function collapseAllAcc() {
			$('#accordion > .panel > .collapse').collapse('hide');
		}


// Double Accordion // 
// =================================================== // 
