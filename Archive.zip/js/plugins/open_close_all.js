location.href = "#";
location.href = "#accordion";location.href = "#";
location.href = "#accordion";location.href = "#";
location.href = "#accordion";
element = document.getElementById("accordion")
alignWithTop = true;
element.scrollIntoView({block: "top"});
element = document.getElementById("accordion")
alignWithTop = true;
element.scrollIntoView({block: "top"});
element = document.getElementById("accordion")
alignWithTop = true;
element.scrollIntoView({block: "top"});
element = document.getElementById("accordion")
alignWithTop = true;
element.scrollIntoView({block: "top"});
$('.closeall').click(function(){
  $('.collapse.show')
    .collapse('hide');
});

$('.openall').click(function(){
  $('.collapse:not(".show")')
    .collapse('show');
});

